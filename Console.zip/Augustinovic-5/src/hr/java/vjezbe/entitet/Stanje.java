package hr.java.vjezbe.entitet;

public enum Stanje {
	
	NOVO, //Stanje.values()[0
	IZVRSNO,
	RABLJENO,
	NEISPRAVNO
	

}

